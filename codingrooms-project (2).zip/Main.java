public class Main {

    public static void main(String[] args) {
        
        
        System.out.println("      ()                 ()");
        System.out.println("      /\\                 /\\");
        System.out.println("     /**\\               / *\\");
        System.out.println("    /* **\\             / * *\\");
        System.out.println("   / * * *\\           /* *  *\\");
        System.out.println("  /* * * * \\         / *  *  *\\");
        System.out.println(" /* * * * * \\       /* *  *  * \\");
        System.out.println("/_*_*_*_*_*_*\\     /_*_*_*_*_*_*\\");
        System.out.println("                (^)             ");
        System.out.println("                / \\                 ");
        System.out.println("               /* *\\               ");
        System.out.println("              / * **\\             ");
        System.out.println("             / *  * *\\           ");
        System.out.println("            /* * * * *\\         ");
        System.out.println("           /* * * * * *\\       ");
        System.out.println("          /_*_*_* _*_*_*\\     ");
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println();
    }
}
